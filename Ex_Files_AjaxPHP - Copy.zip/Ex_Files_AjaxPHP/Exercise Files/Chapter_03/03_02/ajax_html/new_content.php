This is the new content which has been loaded by Ajax.
