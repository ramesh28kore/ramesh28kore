
<?php include('includes/header.php'); ?>

  <div id="page-content">
    <h1>Main page</h1>
  </div>

<?php include('includes/footer.php'); ?>
